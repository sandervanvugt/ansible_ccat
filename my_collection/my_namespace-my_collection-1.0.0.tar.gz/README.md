this collection includes a demo filter
